# MyLife – Travail & Sport (version 1)

Application web mobile personnelle gratuite et sans compte. Tu peux l'installer sur l'écran d'accueil de ton iPhone ou Android après l'avoir hébergée sur un site HTTPS.

## Fonctionnalités

- Tableau de bord du mois : heures travaillées, jours travaillés, séances de sport terminées.
- Calendrier mensuel avec matin (M), après-midi (A), nuit (N), repos (R), horaires personnalisés et séances de sport.
- Ajout, modification et suppression d'un service.
- Génération de rotations personnalisables sur 28, 56, 84 ou 168 jours. Exemple **M,M,A,A,N,N,R,R**, à adapter à la vraie rotation de travail. Les services existants sont préservés sauf si « Remplacer » est coché.
- Enregistrement de séances de sport avec date, heure, durée et notes. Suivi des séances réalisées.
- Export et import de sauvegardes JSON.
- Accès hors ligne après une première visite depuis une adresse HTTPS.

## Mise en ligne gratuite avec GitHub Pages

1. Crée un compte sur https://github.com si nécessaire.
2. Crée un nouveau dépôt **public** nommé par exemple `mylife`.
3. Ajoute les fichiers de ce dossier **à la racine du dépôt** : `index.html`, `manifest.webmanifest`, `sw.js`, `icon-192.png` et `icon-512.png`. Ne téléverse pas le fichier ZIP directement : il faut son contenu extrait.
4. Dans le dépôt, ouvre **Settings → Pages → Build and deployment**, choisis **Deploy from a branch**, sélectionne `main` puis `/(root)`, puis **Save**.
5. Dans **Settings → Pages**, ouvre le lien du site (généralement `https://ton-pseudo.github.io/mylife/`).
6. Sur iPhone : ouvre ce lien dans Safari, menu Partager → **Sur l’écran d’accueil** → active **Ouvrir comme app** si proposé, puis **Ajouter**.
7. Sur Android : ouvre le lien dans Chrome, puis menu → **Installer l'application** ou **Ajouter à l'écran d'accueil**.

GitHub Pages est gratuit pour les dépôts publics. Le **code** du site sera public, mais tes horaires et séances ne sont jamais enregistrés dans le dépôt GitHub : ils sont stockés localement dans le navigateur de ton appareil.

## Tester sur ordinateur (facultatif)

Dans ce dossier, exécute : `python -m http.server 8000` puis ouvre `http://localhost:8000` dans ton navigateur.

## Important

- Les données ne sont **pas synchronisées** entre appareils et peuvent disparaître si tu effaces les données du navigateur. Exporte régulièrement une sauvegarde dans Réglages.
- Pas de notification, d'authentification ou de suivi de données de santé dans cette version.
- Les horaires M/A/N par défaut sont 06:00–14:00, 14:00–22:00 et 22:00–06:00 : tu peux les modifier à la main pour chaque journée.
- Une journée de nuit se terminant le lendemain est prise en compte dans le calcul des heures.
- La durée du service est brute : les pauses ne sont pas déduites.
